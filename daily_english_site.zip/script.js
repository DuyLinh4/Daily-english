
async function loadPlan(){
  const res = await fetch('plan.json');
  const plan = await res.json(); // 12 weeks
  // build week select and day select
  const weekSelect = document.getElementById('weekSelect');
  const daySelect = document.getElementById('daySelect');
  for(let i=0;i<plan.length;i++){
    const opt = document.createElement('option');
    opt.value = i;
    opt.text = plan[i].title;
    weekSelect.appendChild(opt);
  }
  // build day options (84 days)
  const totalDays = plan.length * 7;
  for(let d=1; d<=totalDays; d++){
    const opt = document.createElement('option');
    opt.value = d;
    opt.text = 'Day ' + d + ' (Tuần ' + (Math.ceil(d/7)) + ')';
    daySelect.appendChild(opt);
  }

  // load week 0 by default
  renderWeek(0, plan);

  document.getElementById('weekSelect').addEventListener('change', (e)=>{
    renderWeek(parseInt(e.target.value), plan);
  });
  document.getElementById('gotoDay').addEventListener('click', ()=>{
    const d = parseInt(document.getElementById('daySelect').value);
    renderDay(d, plan);
  });
  document.getElementById('clearAll').addEventListener('click', ()=>{
    if(confirm('Xóa toàn bộ progress?')){
      Object.keys(localStorage).forEach(k=>{ if(k.startsWith('day_')) localStorage.removeItem(k); });
      renderWeek(parseInt(document.getElementById('weekSelect').value), plan);
    }
  });
}

function renderWeek(weekIndex, plan){
  const content = document.getElementById('content');
  content.innerHTML = '';
  const week = plan[weekIndex];
  const header = document.createElement('div'); header.className='card';
  header.innerHTML = '<h2>'+week.title+'</h2><p class="day-title">7 ngày — mỗi ngày 30–45 phút</p>';
  content.appendChild(header);
  // show each day as Day 1..7 with a summary and button view
  for(let i=0;i<7;i++){
    const dayNum = weekIndex*7 + i + 1;
    const dayCard = document.createElement('div'); dayCard.className='card task';
    const left = document.createElement('div');
    left.innerHTML = '<strong>Ngày '+dayNum+'</strong><div class="meta">'+week.tasks[i].skill+': '+week.tasks[i].text+'</div>';
    const right = document.createElement('div');
    right.style.display='flex'; right.style.gap='8px'; right.style.alignItems='center';
    const viewBtn = document.createElement('button'); viewBtn.textContent='Xem ngày'; viewBtn.onclick = ()=> renderDay(dayNum, plan);
    const chk = document.createElement('input'); chk.type='checkbox'; chk.id='day_'+dayNum; chk.checked = localStorage.getItem('day_'+dayNum)==='1';
    chk.addEventListener('change', ()=>{ localStorage.setItem('day_'+dayNum, chk.checked?'1':'0'); updateProgress(weekIndex, plan); });
    right.appendChild(viewBtn); right.appendChild(chk);
    dayCard.appendChild(left); dayCard.appendChild(right);
    content.appendChild(dayCard);
  }
  // progress
  const p = document.createElement('div'); p.className='card';
  p.innerHTML = '<div>Tiến độ tuần: <div class="progress"><i id="progBar" style="width:0%"></i></div></div>';
  content.appendChild(p);
  updateProgress(weekIndex, plan);
}

function updateProgress(weekIndex, plan){
  const base = weekIndex*7+1;
  let done=0; for(let i=0;i<7;i++){ if(localStorage.getItem('day_'+(base+i))==='1') done++; }
  const pct = Math.round((done/7)*100);
  document.getElementById('progBar').style.width = pct+'%';
}

function renderDay(dayNum, plan){
  const content = document.getElementById('content');
  content.innerHTML = '';
  const weekIndex = Math.ceil(dayNum/7)-1;
  const dayIndex = (dayNum-1)%7;
  const dayData = plan[weekIndex].tasks[dayIndex];
  const header = document.createElement('div'); header.className='card';
  header.innerHTML = '<h2>Ngà y '+dayNum+' — '+plan[weekIndex].title+'</h2><p class="day-title">'+dayData.skill+' — '+dayData.text+'</p>';
  content.appendChild(header);

  // task block
  const task = document.createElement('div'); task.className='card task';
  const left = document.createElement('div'); left.innerHTML = '<strong>'+dayData.skill+'</strong><div class="meta">'+dayData.text+' </div>';
  const right = document.createElement('div'); right.style.display='flex'; right.style.flexDirection='column'; right.style.alignItems='flex-end';
  const openLink = document.createElement('a'); openLink.href = dayData.link || '#'; openLink.target='_blank'; openLink.textContent = dayData.link? 'Bắt đầu':'Không có link';
  const chk = document.createElement('input'); chk.type='checkbox'; chk.id='day_'+dayNum; chk.checked = localStorage.getItem('day_'+dayNum)==='1';
  chk.addEventListener('change', ()=>{ localStorage.setItem('day_'+dayNum, chk.checked?'1':'0'); updateProgress(weekIndex, plan); });
  right.appendChild(openLink); right.appendChild(chk);
  task.appendChild(left); task.appendChild(right);
  content.appendChild(task);

  // extra daily actions: note, record
  const extras = document.createElement('div'); extras.className='card';
  extras.innerHTML = '<p><strong>Ghi chú/nghiệp vụ:</strong></p><p>- Ghi 1 câu bạn đã học hôm nay.</p><p>- Ghi âm 30s & nghe lại.</p>';
  content.appendChild(extras);

  // nav
  const nav = document.createElement('div'); nav.className='card';
  const prev = document.createElement('button'); prev.textContent='Trước'; prev.onclick = ()=>{ if(dayNum>1) renderDay(dayNum-1, plan); };
  const next = document.createElement('button'); next.textContent='Tiếp'; next.onclick = ()=>{ if(dayNum < plan.length*7) renderDay(dayNum+1, plan); };
  nav.appendChild(prev); nav.appendChild(next);
  content.appendChild(nav);
}

window.addEventListener('DOMContentLoaded', loadPlan);
