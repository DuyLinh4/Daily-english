
Simple Daily Study Site - A1+ to A2+
Files included:
- index.html
- style.css
- script.js
- plan.json (12-week plan)

Usage:
1. Unzip and open index.html in a browser. For local links to open reliably on desktop, use Live Server or python -m http.server.
2. On mobile, upload to GitHub Pages or Netlify or open the generated DOCX/PDF links.
3. Progress is saved to localStorage (per device/browser).
